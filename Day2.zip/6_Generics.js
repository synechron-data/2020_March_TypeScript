"use strict";
function getLength(arg) {
    return arg.length;
}
console.log(getLength("Hello"));
console.log(getLength(["Hello", "Hi"]));
console.log(getLength([10, 20, 30, 40, 50]));
