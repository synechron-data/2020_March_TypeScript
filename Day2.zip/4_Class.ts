// class Employee {
//     private _name: string;

//     // Multiple constructor implementations are not allowed.
//     // constructor(){
//     //     this._name = "NA";
//     // }

//     // constructor(name:string) {
//     //     this._name = name;
//     // }

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     setName(name: string) {
//         this._name = name;
//     }

//     // Increase Memory Usage
//     // getName = () => {
//     //     return this._name;
//     // }

//     // setName = function(name:string) {
//     //     this._name = name;
//     // }
// }

// var e1 = new Employee();
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// var e2 = new Employee("Manish");
// console.log(e2.getName());
// e2.setName("Ramakant");
// console.log(e2.getName());

// ------------------------------------------ Properties
// class Employee {
//     private _name: string;
//     private _age: number;

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     get Name() {
//         return this._name;
//     }

//     set Name(name: string) {
//         this._name = name;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(value: number) {
//         this._age = value;
//     }
// }

// var e1 = new Employee();
// console.log(e1.Name);
// e1.Name = "Abhijeet";
// console.log(e1.Name);

// -------------------------------------- Parameter (Properties/Members)
// Parameter properties let us create and initialize member variables in one place. 
// It is a shorthand for creating member variables.

// class Employee {
//     constructor(private _name = "NA", private _age = 0) { }

//     get Name() {
//         return this._name;
//     }

//     set Name(name: string) {
//         this._name = name;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(value: number) {
//         this._age = value;
//     }
// }

// var e1 = new Employee();
// console.log(e1.Name);
// e1.Name = "Abhijeet";
// console.log(e1.Name);

// -----------------------------------------  Static Members
// class BankAccount {
//     private static _bankname = "HDFC";

//     constructor(private _accname: string) { }

//     static set BankName(value: string) {
//         BankAccount._bankname = value;
//     }

//     get AccountName(): string {
//         return this._accname;
//     }

//     get BankName(): string {
//         return BankAccount._bankname;
//     }
// }

// BankAccount.BankName = "ICICI";

// var a1 = new BankAccount("Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("Abhijeet");
// console.log("Bank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// -----------------------------------------  Readonly Members

class BankAccount {
    private static _bankname = "HDFC";

    constructor(private readonly _accnumber: number, private _accname: string) { }

    static set BankName(value: string) {
        BankAccount._bankname = value;
    }

    get AccountName(): string {
        return this._accname;
    }

    get BankName(): string {
        return BankAccount._bankname;
    }

    get AccountNumber(): number {
        return this._accnumber;
    }
}

BankAccount.BankName = "ICICI";

var a1 = new BankAccount(1, "Manish");
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccountNumber);
console.log("Account Holder Name: ", a1.AccountName);

var a2 = new BankAccount(2, "Abhijeet");
console.log("Bank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccountNumber);
console.log("Account Holder Name: ", a2.AccountName);