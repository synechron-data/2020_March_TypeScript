// Tuple - Stores a fixed collection of values of same or varied types, 
// maintaining the sequence

// var arr: number[] = [10, 20, 30, 40, 50];
// var arr = new Array<number>(2);
// arr[0] = 10;
// arr[1] = 20;
// arr[2] = 30;

// console.log(arr);
// console.log(arr.length);

// var arr: (string | number)[] = ["Manish", 1];
// arr = ["Manish", 10, "Pune", 20];
// arr = ["Manish", "Pune"];
// arr = [10, 20];
// arr = [1, "Manish"];

// let dataRow: [number, string] = [1, "Manish"];
// dataRow = ["Manish", 1]; // Error
// dataRow = ["Manish", "Pune"];
// dataRow = [10, 20];
// dataRow = [1, "Manish", "Pune"];