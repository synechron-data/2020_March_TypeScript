function CatchAll<T>(target: T, propertyKey: string, descriptor: any) {
    var originalMethod = descriptor.value;

    descriptor.value = function (...args: any[]) {
        try {
            originalMethod.apply(this, args);
        } catch (error) {
            console.log(error.message);
        }
    }

    return descriptor;
};

class DAL {
    @CatchAll
    getCustomers() {
        throw new Error('Exception Thrown!!!');
    }
}

var dObject = new DAL();
dObject.getCustomers();