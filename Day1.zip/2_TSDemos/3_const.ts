const env = "production";
console.log(env);

if (true) {
    const env = "dev";
    console.log("Block", env);
}

const obj = { id: 1 };
console.log(obj);
obj.id = 100;
console.log(obj);

// obj = {};
