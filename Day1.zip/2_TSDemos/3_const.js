"use strict";
var env = "production";
console.log(env);
if (true) {
    var env_1 = "dev";
    console.log("Block", env_1);
}
var obj = { id: 1 };
console.log(obj);
obj.id = 100;
console.log(obj);
