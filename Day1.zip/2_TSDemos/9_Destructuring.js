"use strict";
var numArr = [10, 20, 30, 40, 50, 60, 70, 80, 90];
var x = numArr[0], y = numArr[1], z = numArr.slice(2);
console.log("x = " + x + ", y = " + y + ", z= " + z);
