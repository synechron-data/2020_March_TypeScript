// function Reverse(word: string): string[];
// function Reverse(words: string[]): string[];

// // function Reverse(strOrArr: any) {
// //     if (typeof strOrArr == "string")
// //         return strOrArr.split("").reverse();
// //     else
// //         return strOrArr.slice().reverse();
// // }

// function Reverse(strOrArr: any) {
//     if (typeof strOrArr == "string")
//         return strOrArr.split("").reverse();
//     else
//         return (<string[]>strOrArr).slice().reverse();
// }

// console.log(Reverse("Manish"));
// console.log(Reverse(["PQR", "XYZ", "ABC"]));

// ------------------------------- Typeguards

// var p: number | string;
// p = 10;
// p = "ABC";

function Reverse(word: string): string[];
function Reverse(words: string[]): string[];

function Reverse(strOrArr: string | string[]) {
    if (typeof strOrArr == "string")
        return strOrArr.split("").reverse();
    else
        return strOrArr.slice().reverse();
}

console.log(Reverse("Manish"));
console.log(Reverse(["PQR", "XYZ", "ABC"]));