"use strict";
var emp1 = { id: 1, name: "Manish", address: { city: "Pune" } };
var emp2 = JSON.parse(JSON.stringify(emp1));
emp2.id = 100;
emp2.address.city = "Mumbai";
console.log("1 - ", emp1);
console.log("2 - ", emp2);
