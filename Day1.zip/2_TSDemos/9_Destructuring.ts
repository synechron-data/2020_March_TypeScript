// // ------------------------ Template Literals (Back Tick ``)

// // var d1 = "Hello";
// // var d2 = 'Hello';
// // var d3 = 'H\ne\nl\nl\no';
// // // console.log(d3);

// // var d4 = `H
// // e
// //         l
// // l
// //     o`;
// // console.log(d4);

// var fname = "Manish";
// var lname = "Sharma";
// // var message = "Hello, " + fname + " " + lname;
// // console.log(message);

// var message = `Hello, ${fname} ${lname}`;
// console.log(message);

// // ---------------------------- Object Destructuring
// var emp = { id: 1, ename: "Manish", city: "Pune", state: "MH", pin: 411021 };

// // var id = emp.id;
// // var ename = emp.ename;

// var { id, ename, ...address } = emp;

// console.log(`Id: ${id}`);
// console.log(`Name: ${ename}`);
// console.log(`Address: ${JSON.stringify(address)}`);

// ---------------------------- Array Destructuring
var numArr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// var x = numArr[0];
// var y = numArr[1];

// var [x, , y] = numArr;
// console.log(`x = ${x}, y = ${y}`);

// Swap

// var [x, , y] = numArr;
// console.log(`Before - x = ${x}, y = ${y}`);

// [x, y] = [y, x];

// console.log(`After - x = ${x}, y = ${y}`);

var [x, y, ...z] = numArr;
console.log(`x = ${x}, y = ${y}, z= ${z}`);
// console.log(typeof z);