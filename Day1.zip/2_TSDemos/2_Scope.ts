// // var i = 10;
// // var i = 20;
// // console.log(i);

// // i = 10;
// // console.log(i);
// // var i;

// var i = 100;
// console.log("Before, i is:", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is:", i);
// }

// console.log("After, i is:", i);

// ------------------------------------------

// var i = 10;
// let i = 20;
// console.log(i);

// i = 10;
// console.log(i);
// let i;

var i = 100;
console.log("Before, i is:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is:", i);
}

console.log("After, i is:", i);