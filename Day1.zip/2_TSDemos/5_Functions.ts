// // // Fn Declaration
// // // function hello() {
// // //     console.log("Hello World!");
// // // }

// // // hello();

// // // Fn Expression

// // const hello = function () {
// //     console.log("Hello World!");
// // }

// // // hello();
// // var r = hello();
// // console.log(r);
// // // r = 10;
// // r = undefined;

// var r1: undefined;
// // r1 = 10;  // Error
// r1 = undefined;
// console.log(r1);

// var r2: void;
// // r2 = 10;  // Error
// r2 = undefined;
// console.log(r2);

// var r3: never;
// // r3 = 10;  // Error
// // r3 = undefined; // Error
// console.log(r3);

// var r = (function () {
//     throw new Error("Test");
// })();

// var r1 = (function () {

// })();

// var r2 = (function () {
//     return 10;
// })();

// ----------------------------------

// function add1(x: number, y: number): number {
//     return x + y;
// }

// var add2 = function (x: number, y: number): number {
//     return x + y;
// }

// var add3: (a: number, b: number) => number;
// add3 = function (x: number, y: number): number {
//     return x + y;
// }

// var a: number;
// a = 10;

// var add4: (a: number, b: number) => number;
// add4 = function (x, y) {
//     return x + y;
// }

// var add5: (a: number, b: number) => number;
// add5 = (x, y) => {
//     return x + y;
// }

// var add6: (a: number, b: number) => number;
// add6 = (x, y) => x + y;

// console.log(add1(23, 45));
// console.log(add2(23, 45));
// console.log(add3(23, 45));
// console.log(add4(23, 45));
// console.log(add5(23, 45));
// console.log(add6(23, 45));

// --------------------------------------

// var i = 10;
// console.log(i);
// console.log(typeof i);

// var f = function () { };
// console.log(f);
// console.log(typeof f);

// ------------------------------------------- Callbacks

var employees = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];

// var pune_employees = [];

// function filterFn(item: any) {
//     return item.city === "Pune";
// }

// for (let i = 0; i < employees.length; i++) {
//     if (filterFn(employees[i]))
//         pune_employees.push(employees[i]);
// }

// // -------------------------------------------------
// function filterFn(item: any) {
//     return item.city === "Pune";
// }

// var pune_employees = employees.filter(filterFn);

// console.log(pune_employees);

// -------------------------------------------------

// var pune_employees = employees.filter(function (item: any) {
//     return item.city === "Pune";
// });

// console.log(pune_employees);

// // -------------------------------------------------

// var pune_employees = employees.filter((item) => {
//     return item.city === "Pune";
// });

// console.log(pune_employees);

// -------------------------------------------------

var pune_employees = employees.filter(item => item.city === "Pune");
console.log(pune_employees);

