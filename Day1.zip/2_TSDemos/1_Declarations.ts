// Implicitly Typed
// var data = 10;
// data = "ABC";

// var s = "ABC";

// var data;
// data = "ABC";
// data = 10;

// Explicitly Typed
var age: number;
age = 10;
// age = "ABC";

function add(x: number, y: number) {
    return x + y;
}

add(12, 45);
// add(12, "ABC");

// var p = new Promise()

// number / string / boolead / undefined / Symbol / Array / Object / Date / RegExp / Function / void  (Based on Config)

// any / never / Tuple / Interface / Enum / Class
