// ----------------------------------- Rest Parameters
function Average(...args: number[]) {
    var sum = 0;

    for (let i = 0; i < args.length; i++) {
        sum += args[i];
    }

    if (args.length > 0) {
        return sum / args.length;
    } else {
        return sum;
    }
}

console.log(Average());
console.log(Average(1));
console.log(Average(1, 2));
console.log(Average(1, 2, 3, 4, 5));
console.log(Average(1, 2, 3, 4, 5, 6, 7, 8, 9));

var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(Average(...numbers));   // Spread Operator